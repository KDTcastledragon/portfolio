@echo off
setlocal
cd /d "%~dp0agent"
title PDFS Agent
rem smartctl needs administrator rights to read SMART data. Re-launch elevated if needed.
net session >nul 2>&1 || (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
echo ============================================================
echo  HPDFS Agent - reads this PC's disk health and sends it to
echo  the dashboard at http://43.202.208.133:8084
echo ============================================================
echo.
call :findpy || goto :nopy
if not exist "%~dp0.venv\installed.ok" (
  echo  Installing packages, first run only...
  %PY% -m venv "%~dp0.venv" || goto :fail
  "%~dp0.venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt || goto :fail
  echo ok> "%~dp0.venv\installed.ok"
)
echo  Sending every 5 minutes. Close this window or press Ctrl+C to stop.
echo.
set PYTHONIOENCODING=utf-8
"%~dp0.venv\Scripts\python.exe" -u agent.py
pause
exit /b 0

:findpy
for %%V in (3.13 3.12 3.11) do (
  py -%%V -c "import sys" >nul 2>&1 && (set "PY=py -%%V" & exit /b 0)
)
python -c "import sys; sys.exit(sys.version_info < (3,9))" >nul 2>&1 && (set "PY=python" & exit /b 0)
exit /b 1

:nopy
echo.
echo  Python 3.11 or newer is required. Install it from
echo    https://www.python.org/downloads/
echo  and check "Add python.exe to PATH" during install. Then run this file again.
start "" https://www.python.org/downloads/
pause
exit /b 1

:fail
echo.
echo  Setup failed. An internet connection is needed on the first run.
pause
exit /b 1
